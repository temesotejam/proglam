# 現行ボート用プログラム構成・周期・タスク分担

作成日: 2026-08-01

この文書は、ソースコードで設定されている値を一覧化した引継ぎ資料である。**設定周期は実測周期ではない**。実際の更新率、最大間隔、キュー欠落、SD待ち時間はRUNのBIN/TXTを解析して判定する。現在CoreS3に書き込み済みなのは「CoreS3暫定通信・SD・GNSS代替」であり、BNO08Xを含む本来の通信側XIAOではない。

## 現在の全体構成

```text
制御側XIAO ESP32S3                         CoreS3（現在書込み済み）
BNO08X / VL53L5CX / INA226 / PCA9685       Port B: 制御リンク 921600 bps
VESC UART / 安全状態機械                    Port C: GNSS 115200 bps
          │ UART 921600 bps                 内蔵microSD / タッチ画面
          └───────────────────────────────────────────────┘

本来の通信側XIAO ESP32S3 Sense（現在は不在）
GNSS / 比較BNO08X / UART→SD / SoftAP Web UI / 時刻同期
```

制御側のVESCはCoreS3へ接続しない。CoreS3代替はVESC、PCA9685、ToF、INA226、BNO08Xを制御しない。

## 制御側XIAO: 固定設定と実行分担

| 実行主体 | コア/優先度 | 周期・起動条件 | 内容 |
| --- | --- | --- | --- |
| `Bno` FreeRTOSタスク | core 0 / 優先度3 | BNO INT通知、または2 msのフォールバック | BNO I2C 100 kHzを唯一所有。SH-2を最大8回サービスし、コールバック結果を96件キューから取り出す。アクティブサービス後は1 tick譲る。 |
| `LinkTx` FreeRTOSタスク | core 0 / 優先度4 | 1 tickごと | 制御側→通信側UART送信キューを排出。Heartbeatを100 ms周期で送信。BNOタスクより高優先度で、リンク飢餓を防ぐ。 |
| メイン`loop` | 固定コア指定なし / 末尾で1 ms delay | できるだけ速く反復 | UART受信（1周最大512 bytes）、通信断監視、ToF、INA、VESC、状態機械、USB診断を実行。固定周期スケジューラではない。 |

### 制御側センサ・出力の設定周期

| 対象 | 設定値 | 備考 |
| --- | --- | --- |
| BNO専用I2C | 100 kHz | D4=SDA、D5=SCL、D3=INT、D2=RST。 |
| BNO通常/推定器入力 | 加速度・較正ジャイロ 50 Hz、較正地磁気 20 Hz | 通常環境は20 ms / 20 ms / 50 ms。 |
| BNO BOAT24/BOAT23 | 加速度100 Hz、較正ジャイロ100 Hz、較正地磁気20 Hz | 環境`bno_accel100_gyro100_mag20_int_60sec`は60秒。 |
| BNO BOAT22 | 加速度100 Hz、較正ジャイロ100 Hz | 地磁気なし。 |
| BNO BOAT21 | Game Rotation Vector100 Hz、較正ジャイロ100 Hz | 比較用条件。 |
| ToF | 環境により8x8 10/15 Hz、4x4 15/30 Hz | 現行設定は選んだ`BOAT_EXPERIMENT`で決まる。64ゾーン生値を送る。 |
| INA226 | 通常50 Hz、Fast100 Hz | 20 ms、Fastプロファイル時10 ms。共有I2C。 |
| VESC状態要求 | 50 Hz | UART 115200 bps、20 ms。 |
| VESC Duty keepalive | 出力試験時20 Hz | 50 ms。ただし`kDryRunActuators=true`のため非ゼロDutyは遮断。 |
| PCA9685 | 50 Hz PWM | 実際のサーボ更新はメインループ内で行う。`kServoControlUs=20 ms`は定義されるが、現実装はこの値で周期ゲートしていない。 |
| EstimatedState送信 | 10 Hz | BNOタスクから100 msごと。 |
| PrimaryImuSnapshot送信 | 20 Hz | P1/主副IMU比較向け、50 msごと。 |
| UARTリンク | 921600 bps 8N1 | 制御側D6=RX、D7=TX。通信断フェイルセーフ500 ms。 |

制御側は起動、DISARM、STOP、E-STOP、FAULT、リンク断でVESC Duty 0とPCA9685 Full OFFを要求する。E-STOPはラッチする。現在はDRY_RUNである。

## 本来の通信側XIAO（不在時の基準実装）

| 実行主体 | コア/優先度 | 周期・起動条件 | 内容 |
| --- | --- | --- | --- |
| `CommBno` | core 0 / 優先度3 | INT通知、または2 msフォールバック | 比較BNOのSH-2イベントを96件キューへ格納し、加速度100 Hz・ジャイロ100 Hz・地磁気20 Hz（BOAT24時）をログへ渡す。 |
| `ControlRx` | core 0 / 優先度2 | 1 tickごと | 制御側UARTをCOBS/CRC32復号し、制御テレメトリをログキューへ投入する。 |
| `LogWriter` | core 1 / 優先度2 | 通知または5 ms | 160件キュー、8 KiB RAMバッファ、512 byte単位でmicroSDへ書く。 |
| GNSS処理 | メイン処理 + 送信タスク | 受信は最大512 bytes/サービス、NAV 100 ms | NMEAを解析し、GNSS_NAVを制御側へ送る。GNSS状態は1秒ごとにログ。 |
| Web UI | メイン処理 | HTTP要求時、表示更新設定50 ms | SoftAP、SD開始停止、状態参照、STOP/E-STOPを提供。HTTP内でセンサI2Cを行わない。 |

本来の通信側のUARTは921600 bps、GNSSは115200 bps。ログ外側時刻はSD書込み時刻ではなくログキュー投入時刻である。SD待ち、キュー高水位、ドロップ、CRC、COBS、BNOデコードはBIN/TXTに残す。

## CoreS3暫定通信・SD・GNSS代替（現在書込み済み）

| 実行主体 | コア/優先度 | 周期・起動条件 | 内容 |
| --- | --- | --- | --- |
| メイン`loop` | 固定コア指定なし / 末尾で1 ms delay | できるだけ速く反復 | 制御側UART受信、GNSS受信（1回最大512 bytes）、GNSS_NAV/Heartbeat送信、タッチ操作、画面更新を処理。 |
| `SdWriter` | core 1 / 優先度2 | キュー通知、または10 ms | 96件のフレームキューをSDへ書く。8 KiBバッファを512 byte単位で書込み、`LOG STOP`時は排他して残キューを確定。 |
| GNSS_NAV送信 | メイン処理 | 100 ms | fixの有無と各フィールド有効フラグを含め、制御側へ送る。 |
| Heartbeat送信 | メイン処理 | 100 ms | 制御側リンクの生存確認。 |
| GNSS状態ログ | メイン処理 | 1秒 | GNSSバイト数、文数、妥当文数、エラー、鮮度を記録。 |
| 画面更新 | メイン処理 | 200 ms | SD状態、fix、緯度経度、速度、制御側フレーム、キュー、UARTエラーを表示。 |

### CoreS3暫定配線

| 用途 | CoreS3 | 相手 |
| --- | --- | --- |
| GNSS RX/TX | Port C GPIO18/RX、GPIO17/TX | GNSS TX/RX、115200 bps |
| 制御リンク RX/TX | Port B GPIO9/RX、GPIO8/TX | 制御側D7/TX、D6/RX、921600 bps |
| SD | 内蔵 | CS=4、SCK=36、MISO=35、MOSI=37 |

## 現在のログ内容

- 制御側→通信側: BNO（有効な測定/P1時）、ToF 64ゾーン、INA226、VESC状態、安全状態、EstimatedState、PrimaryImuSnapshot、Heartbeat、GNSS処理結果、ベンチ診断。
- GNSS側: 生NMEA文、解析したfix、GNSS状態、GNSS_NAV。
- CoreS3代替: 上記のうち制御側から受信したフレームに加え、CoreS3で取得したGNSS生文/fix/状態/GNSS_NAV。CoreS3自身のBNOログは存在しない。

## 検証状態と注意

CoreS3代替はビルド・書込み・フラッシュハッシュ照合のみ完了している。SD認識、GNSS fix、制御側リンク、GNSS_NAV往復、BIN/TXT確定は未検証である。よって周期表のCoreS3部分は実装値であって性能保証値ではない。

制御側XIAOについても、実際に書かれている環境番号は再接続時にUSB診断またはログの`experiment`欄で確認すること。`platformio.ini`には複数の固定条件環境があるため、ソースだけから現在の実機環境を断定しない。