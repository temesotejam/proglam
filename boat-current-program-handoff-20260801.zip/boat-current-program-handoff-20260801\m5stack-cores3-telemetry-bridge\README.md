# CoreS3 通信・SD・GNSS代替ブリッジ

通信側XIAOが不在の間だけ使用するCoreS3専用ファームウェアです。Port Aチェッカーとは別プロジェクトであり、VESC、PCA9685、ToF、INA、BNO08Xは扱いません。

- 内蔵microSDへ`/BOATLOG/RUNxxxx.BIN`と概要TXTを保存します。制御側UARTフレームとGNSSの生NMEA文・解析fix・状態を既存のXIAOログ互換レコードで保存します。
- GNSSはPort C（GPIO18=RX、GPIO17=TX）、115200 bps 8N1です。GNSS TX→CoreS3 GPIO18、GNSS RX←CoreS3 GPIO17（設定変更が必要な場合のみ）、GND共通にします。
- 制御側XIAOとのリンクはPort B（GPIO9=RX、GPIO8=TX）、921600 bps 8N1です。制御側D7/TX→CoreS3 GPIO9/RX、制御側D6/RX←CoreS3 GPIO8/TX、GND共通にします。
- 100 msごとにGNSS_NAV、100 msごとにHeartbeatを制御側へ送信します。BNO08Xが無いことは正常な構成差で、BNOを前提としたベンチマークやP1は実行しません。

画面下部の`LOG START`で記録を開始し、`LOG STOP`でSDを閉じてTXT概要を確定します。右の`STOP`は制御側へ安全停止を送ります。起動時は記録停止で、VESCやサーボへの指令は一切送りません。

```powershell
cd m5stack-cores3-telemetry-bridge
pio run
pio run -t upload --upload-port COM6
```