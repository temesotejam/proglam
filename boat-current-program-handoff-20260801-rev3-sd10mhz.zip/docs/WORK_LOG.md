# 作業ログ

## 2026-08-01 — BNO08X→ESKF入力の修正と実機確認

- 添付指示に従い、UART配線・921600 bps/8N1・COBS+CRC・Wi-Fi設定・メッセージ型・SDログ形式・ESKFの数式/状態/ノイズ/取付/GNSS遅延・物理出力設定は変更しなかった。
- RUN0001を全15,377レコードから再解析した。ログ時刻の実録時間は92.853619秒。Type 24は1,788件で、BNO生タイムスタンプはAccel/gyro/magで逆行・重複を含んだ。
- 原因: `bnoEvent()` がジャイロの `sensorUs`（SH-2生タイムスタンプ）を `shadowEskf.predict()` に渡していた。`Shadow::predict()` は単調増加を要求するため、逆行値を拒否してIMU ageが未受信値のままになった。
- 修正: ESKFの予測時刻のみ、単調なMCU受信時刻 `rxUs` を使用するよう変更。`sensorUs`はPrimaryImuSnapshotのログ値として保持し、UARTプロトコルを変えていない。BNO処理数、再初期化数、受信年齢、ESKF候補/対/予測/受理/理由別拒否をシリアル診断へ追加。
- `bno_accel100_gyro100_mag20_int_60sec` をビルド（RAM 111,076 / 327,680、Flash 557,925 / 3,342,336）し、COM4、MAC 34:85:18:ab:fa:90へ書込み。全領域のハッシュ照合成功。
- 実機診断: BNOは0x4A、init/reinit=1/0。最終読出し時にAccel/Gyro/Mag=30,612/24,213/6,054、ESKF candidate/pair/call/accepted=24,213/24,213/24,213/24,213、全拒否理由=0。ALIGNINGは2,003,559 us・201サンプルで完了。
- Core `/api/eskf`でRUNNING(2)、health=Degraded(1; mount_valid=0)、IMU年齢4.2 ms、time_reversals=0、imu_gaps=0、有限値・共分散有効、shadow_only=true、actuator_output_enabled=falseを確認。
- RUN0002をSDへ保存しPCへ回収。TXT: normal_stop=1、records=12,317、queue_drops=0、sd_write_errors=0。開始前後でUART CRC/COBS/lengthカウンタは0/15/17のままで、試験中増加は0。
- RUN0002の実録時間は74.233763秒。ESKF State 1,432件は全件RUNNING・Degraded、IMU年齢は平均3,576.6 us、最小252 us、最大12,566 us、reset=0、shadow_only=1、actuator_output=0。Health 368件は全件finite/covariance valid、最終imu_gaps=0、time_reversals=0。
- 静止中にもNED位置・速度が大きくドリフトした。今回は入力時刻の根本原因だけを修正する範囲のため、ESKF数式・ノイズ・取付設定は変更していない。
## 2026-08-01 — health理由・BNOイベント時刻診断の追加

- 添付指示に従い、ESKF数式、状態次元、ノイズ、BNO取付値、GNSS/ToF観測、UART、Wi-Fi、SDバイナリ形式、メッセージpayload、出力無効設定を変更しなかった。予測時刻は引き続きXIAO受信時刻`rxUs`である。
- `eskf.cpp`のhealth判定を確認。ALIGNING完了時に`kEskfMountValid=false`なら`publicHealth_=Degraded`、trueならValidとなる。`state()`/`health()`はIMU staleまたは非有限値をInvalidにする。GNSS/ToF未使用、bias値、不確かさ、観測timeoutはDegradedへ遷移させる条件ではない。今回のDegraded直接理由はmount未検証だけ。
- CoreS3 `/api/eskf` とWeb UIへ `health_reason` と `health_diagnostic_mask` を追加。実機は `health_reason=mount_unvalidated`、mask=129（mount未検証=1、GNSS未受信の観測状態=128）。判定条件は変更していない。
- BNO Readerへ、Accel/Gyro/Magイベント別に`uint64_t`・µsのSH-2 `sensorUs`と単調なXIAO `rxUs`を集計する診断を追加。unique数はPSRAM上の8192スロット集合で正確に集計し、連続重複、逆行、rollover、signed sensor dt、rx dt、対応する最初/最後の時刻対、生値の軸別平均・標準偏差・min/max・norm・非有限値数をUSBシリアルへ出力する。
- 実機起動確認ではAccel/Gyro/Magの`rxUs`平均dtは約7.91/10.00/40.01 ms、`sensorUs`は逆行が多数、rollover=0、unique集合overflow=0。BNO生加速度平均は約[-5.953,-1.188,-7.849] m/s²で、現時点のidentity入力（ESKF入力と同じ）ではFRD水平静止の期待[0,0,-9.80665] m/s²と不一致。軸試験で取付を確定するまで変換値を変更しない。
- CoreS3の既存ログAPIへ`duration_s=1..600`を追加。開始時刻から指定時間で自動停止する。バイナリログレコード形式と通信payloadは不変。
- XIAO環境を再ビルド（RAM 111,724 / 327,680、Flash 561,681 / 3,342,336）しCOM4へ書込み。CoreS3環境を再ビルド（RAM 145,444 / 327,680、Flash 1,015,245 / 6,553,600）し、通常スタブ失敗後にROM no-stub方式でCOM6へ書込み、全イメージのhash照合に成功。
- 次は、機体を水平な固定台へ置いて触れないことを確認後、XIAOの`imu_stats_reset`とCoreの`POST /api/log/start?duration_s=60`でRUN0003以降の正確な静止ログを取得する。
## 2026-08-01 — 静止試験のログ基盤診断

- 失敗したP1生BNOキャプチャがXIAO側で有効のまま残り、Coreへ約500 frame/sを送っていた。BOAT_EXPERIMENT=24の同一XIAOファームウェアをCOM4へ再書込み（Flash 561,745 bytes、RAM 111,724 bytes、全イメージhash verified）してP1状態を解除した。
- Coreの10秒ログ診断で、`SdWriter`（4KB stack）にStack canary watchpointを確認した。SD CMD18/CMD0D失敗の後にCore 1 panicし、RUN0004--RUN0010は0 byteとなった。原因はSD/FAT処理を含む書込みタスクのスタック不足である。
- Coreを修正: `SdWriter` stack=12KB、優先度=1、反復ごとに1ms譲渡。終了要求・flush・close・TXT要約をSD書込みタスクに一元化し、記録中のSD一覧/ダウンロードを409で拒否した。Core build成功（RAM 145,452/327,680、Flash 1,015,721/6,553,600）、COM6 ROM no-stub書込み・全hash verified。
- 修正後RUN0011は10秒ログとして208,556 byteとTXTを正常保存し、再起動直後の直接ダウンロードでPCへ回収できた。HTTP Serverは最初の要求後に不安定化するため、本60秒測定はCore再起動直後の最初のHTTP要求で開始し、終了後にCoreを再起動してSDから回収する必要がある。現時点で60秒本測定は未開始。- RUN0012: Core再起動直後の最初のHTTP要求で`duration_s=60`開始応答を確認し、60秒待機後に再起動して回収したが、BINは0 byteでTXTなし。静止データとして無効。60秒記録中のCoreシリアル監視が次の必須診断である。- 60秒監視ログ（RUN0013）で本因を確定: 開始後`rec=63`で `[sd_diskio.cpp] sdCommand(): Card Failed! cmd: 0x0d`、続いてCMD00が連続失敗し、`fopen(/sd/BOATLOG/RUN0013.TXT) failed`。以後`logging=0, rec=63, q=3`のままCoreメインループ/UARTは継続。従って現在の0 byteログ原因はmicroSDのSPIカード応答喪失（接触、電源、配線、または25 MHz信号品質）であり、ESKF・UARTプロトコル・SD書込みタスクのスタックではない。- SDカード再装着後のRUN0014（10秒診断）でも`rec=512`まで書込み後に`CMD18`失敗、続いてCMD0D/CMD00およびTXT fopen失敗を再現。従ってカード再装着では解消せず、SPI信号品質・給電・カード自体のいずれかが原因。現在の25MHz SDクロックは未変更。
## 2026-08-01 — SD SPI 10 MHz 切り分け（書き込み待ち）

- ユーザー承認により、CoreS3のSD初期化だけを SD.begin(kSdCsPin, SPI, 25000000) から 10000000 へ変更した。UART、ESKF、センサ設定、ログ形式は変更していない。
- CoreS3ファームウェアのビルドは成功（RAM 145,452 / 327,680 bytes、Flash 1,015,721 / 6,553,600 bytes）。
- ROM no-stub方式でCOM6への書き込みを試行したが、Windowsのシリアルポート一覧にCOM6が存在せず、COM4（制御側）だけを検出したため、未書き込み・未検証。再接続後に10秒ログでCMD18/CMD0D/CMD00エラーの有無を確認する。

## 2026-08-01 — SD SPI 10 MHz 検証結果

- 10 MHz版をCoreS3（COM6、MAC 30:ed:a0:d4:bf:40）へROM no-stub方式で書き込み、全イメージのhash verifiedを確認した。
- 再起動後、SoftAP BOAT-ESKF-CORE で最初のHTTP操作として POST /api/log/start?duration_s=10 を実行し、HTTP 202を確認した。
- シリアル診断ではログ中に ec=65 の後、sdCommand(): Card Failed! cmd: 0x18、続いてCMD0D/CMD00、open(/sd/BOATLOG/RUN0016.TXT) failed を確認した。10 MHzへ下げても25 MHz時と同じSD SPI失敗であり、クロック速度だけが原因ではない。
- UART・ESKF・センサ設定・ログ形式は変更していない。次の切り分け対象はmicroSDカード、カードソケット接点、3.3 V電源、およびSD SPI配線/信号品質である。

## 2026-08-01 — 作業中断時点の保存

- 次回の引継ぎ用に、ソース・設定・docs・PC解析ツール（ビルド生成物を除く）を oat-current-program-handoff-20260801-rev3-sd10mhz.zip としてワークスペース直下へ保存した。
- 次回は docs/PROJECT_CONTEXT.md、docs/WORK_PLAN.md、docs/WORK_LOG.md の順に確認し、SDの次の切り分けをmicroSDカード交換から再開する。CoreS3にはSD SPI 10 MHz版が書き込み済みである。
